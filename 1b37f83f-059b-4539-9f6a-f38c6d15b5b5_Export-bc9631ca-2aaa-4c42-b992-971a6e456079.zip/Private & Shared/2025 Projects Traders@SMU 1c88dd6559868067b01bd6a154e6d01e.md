# 2025 Projects Traders@SMU

Owner: Laurens Christian
Created time: April 1, 2025 2:13 PM
Last edited: April 28, 2025 8:19 PM

**Assignment Date:** Wednesday, April 9th, 2025
**Due Date:** End of Week of April 28th - May 2nd, 2025
**Group Size:** Max 3 people

---

## General Guidelines & Expectations

These projects aim to provide hands-on experience in quantitative finance. Success requires technical skills, analytical thinking, and clear communication.

## Groups

|  **Category (L1/L2)** | **Chosen Project** | **Member 1** | **Member 2** | **Member 3** | **Group Mentor** |
| --- | --- | --- | --- | --- | --- |
| L1 | L2 #5 | Lucas Bernal | Will Zimmer | Aryan Bonigala | Lauren |
| L1 | 4 | Max Fan | Zabe Nash | Gabe Pringle | Julian Cabrera  |
| L1 | 5 | Mateo Tamarozzi | Finn Ihlanfeldt | Owen Merill | Laurens |
| L1 | 1 | Will Brett | Dillon Foord | Andrew Brysh | Sebastian Chacon |
| L1 | L2 5 | Valerio Zivec  | Muxin Ge  | Aaron Hidalgo | Mason Tuller |
| L1 | 7 | Demetrios Lahiri | William Kroeger  | Morgan Eun | Laurens |
| L1 | 8 | Pablo Diaz | Gia Singh  | Georgina Margolis  | Julian Cabrera  |
| L2 | 4 | Miguel Gutierrez | John Parker | Luke Welch | Lauren |
| L2 |  | Yash Shah | Hillary Bhuiyan | Jake Wicks | Mason |
| L2 | 6 | Dylan Terayama | Grant Simon | Vivaan Gupta | Sebastian Chacon |

## Project Types & Objectives

### Layer 1: Foundational Quantitative Exploration

- **Focus:** Understanding and applying fundamental concepts, data analysis, and basic modeling. Emphasis on the research process & clear communication / presentation
- **Expectations:** Clear problem definition, standard data gathering/cleaning, applying foundational analysis/models (regression, correlation, descriptive stats), clear code, basic interpretation, acknowledging limitations.

### Layer 2: Applied Quantitative Strategy & Modeling

- **Focus:** Developing, implementing, and rigorously evaluating quantitative models or trading strategies. Requires deeper technical dive and validation.
- **Expectations:** Specific testable hypothesis/strategy, potentially more complex data handling, advanced modeling/statistical techniques (ML, time series models, cointegration), structured backtesting (if applicable) avoiding biases, rigorous performance evaluation, efficient code, critical analysis of results and risks.

---

## Layer 1 Project Options

1. **Sector Performance vs. Market Benchmark:**
    - **Objective:** Analyze how a specific market sector (e.g., Energy - XLE, Technology - XLK) has performed relative to the broader market (e.g., S&P 500 - SPY) over the last 10 years.
    - **Tasks:** Get historical adjusted closing prices for the sector ETF and SPY. Calculate cumulative returns and plot them on the same chart. Calculate rolling annual returns and volatility for both. Calculate the sector's Beta relative to SPY.
    - **Presentation Goal:** Present visualizations comparing cumulative returns, rolling volatility, and discuss periods of outperformance/underperformance. Explain the calculated Beta and what it implies about the sector's relative risk.
2. **Interest Rate Sensitivity of Different Stock Types:**
    - **Objective:** Visualize the relationship between changes in a key interest rate (e.g., 10-Year Treasury Yield - ^TNX) and the performance of two different types of stocks: a high-dividend utility stock (e.g., DUK) and a growth-oriented tech stock (e.g., NVDA).
    - **Tasks:** Get historical price data for the stocks and the interest rate yield. Calculate monthly returns for all three. Create scatter plots comparing the monthly returns of each stock against the monthly *change* in the 10-year yield. Calculate the correlation between stock returns and yield changes.
    - **Presentation Goal:** Show the scatter plots and correlation coefficients. Discuss whether the stocks appear sensitive to interest rate changes, if they differ in sensitivity, and potential reasons why.
3. **Asset Class Volatility Comparison:**
    - **Objective:** Compare the historical volatility of different asset classes: US Equities (SPY), US Treasury Bonds (TLT), Gold (GLD), and possibly a commodity index (DBC).
    - **Tasks:** Get historical daily price data for the chosen ETFs. Calculate daily returns. Compute the annualized standard deviation (volatility) for each asset class over the full period and potentially over rolling 1-year windows.
    - **Presentation Goal:** Present a table comparing the overall annualized volatility of each asset class. Show a plot of rolling 1-year volatility to visualize how riskiness changed over time. Discuss the relative risk profiles observed.
4. **Simple Portfolio Risk Calculation (Two Assets):**
    - **Objective:** Calculate and visualize the risk (standard deviation) of a simple portfolio composed of two assets (e.g., 60% SPY, 40% TLT) and compare it to the risk of the individual assets.
    - **Tasks:** Get historical daily price data for SPY and TLT. Calculate daily returns. Calculate the standard deviation of returns for each asset individually. Calculate the covariance between their returns. Use the portfolio variance formula `w1^2*var1 + w2^2*var2 + 2*w1*w2*cov(1,2)` to find the portfolio variance, then take the square root for standard deviation. Assume fixed weights (e.g., 60/40).
    - **Presentation Goal:** Explain the concept of portfolio diversification. Present the calculated volatilities (Asset 1, Asset 2, Portfolio) and show how the portfolio's risk compares to the individual components due to correlation/covariance.
5. **Economic Indicator vs. Market Performance:**
    - **Objective:** Explore the relationship between a major US economic indicator (e.g., Unemployment Rate, Inflation Rate - CPI) and S&P 500 (SPY) performance.
    - **Tasks:** Get historical monthly data for the chosen indicator (e.g., from FRED) and SPY monthly returns. Visualize the indicator and SPY returns over time on separate plots or a combined plot with dual axes. Create a scatter plot comparing the indicator's level (or change) to the subsequent month's SPY return. Calculate the correlation.
    - **Presentation Goal:** Show the visualizations and correlation. Discuss whether a clear relationship exists in the historical data, acknowledging limitations (correlation vs. causation, lags).
6. **Dividend-Paying Stocks vs. Non-Dividend Stocks Analysis:**
    - **Objective:** Compare the historical performance and volatility of a representative dividend-paying stock ETF (e.g., SCHD or VYM) versus a broad market index ETF (SPY) or a growth-focused ETF (QQQ).
    - **Tasks:** Get historical adjusted closing prices for the chosen ETFs. Calculate and plot cumulative returns. Calculate annualized returns and volatility for both ETFs over the period.
    - **Presentation Goal:** Present charts comparing returns and a table summarizing risk/return metrics. Discuss the trade-offs observed between the dividend-focused ETF and the benchmark (e.g., potentially lower volatility but different return profile).
7. **Calculating and Comparing Beta for Tech Stocks:**
    - **Objective:** Calculate the Beta coefficient for several large-cap technology stocks (e.g., AAPL, MSFT, GOOG, AMZN) relative to the Nasdaq 100 index (QQQ).
    - **Tasks:** Get historical daily or weekly price data for the stocks and QQQ (at least 3-5 years). Calculate returns. For each stock, perform a linear regression of its returns against QQQ's returns. The slope of the regression line is the Beta.
    - **Presentation Goal:** Present a table comparing the calculated Betas for each tech stock. Explain what Beta represents and discuss the relative market risk of these stocks based on their Betas.
8. **Visualizing Simple Moving Average Crossovers:**
    - **Tasks:** Get historical daily price data for the stock. Calculate two SMAs (e.g., 50-day and 200-day). Plot the stock price along with the two SMAs on the same chart. Identify and mark the points on the chart where the shorter SMA crosses above (potential buy signal) and below (potential sell signal) the longer SMA. Backtest this on multiple stocks.
        - **Objective:** Create visualizations showing Simple Moving Average (SMA) crossovers for a specific stock (e.g., TSLA) and highlight potential buy/sell signals.
    - **Presentation Goal:** Show the plot with the price, SMAs, and marked crossover points. Explain the concept of SMA crossovers as a technical indicator in backtesting.

---

## Layer 2 Project Options

1. **Pairs Trading Strategy Backtest (Specific Pair):**
    - **Objective:** Develop and backtest a pairs trading strategy for a historically correlated pair (e.g., KO vs. PEP, or GLD vs. GDX).
    - **Tasks:** Get historical price data for the pair. Calculate the spread (e.g., price ratio or difference). Standardize the spread (e.g., using z-score). Define entry rules (e.g., enter short pair when z-score > 1.5, long when < -1.5) and exit rules (e.g., exit when z-score crosses 0). Implement a backtest calculating P&L, considering simple transaction costs.
    - **Presentation Goal:** Explain pairs trading and cointegration/correlation analysis for pair selection (even if basic). Present backtest results (equity curve, Sharpe ratio, max drawdown, trade statistics). Discuss parameter sensitivity and limitations.
2. **Bollinger Band Mean Reversion Strategy Backtest:**
    - **Objective:** Implement and evaluate a mean reversion strategy using Bollinger Bands on a volatile stock or ETF (e.g., ARKK, USO).
    - **Tasks:** Get historical price data. Calculate Bollinger Bands (e.g., 20-day SMA +/- 2 standard deviations). Define entry rules (e.g., buy when price touches lower band, sell/short when price touches upper band) and exit rules (e.g., exit when price crosses back over the SMA). Implement a backtest calculating performance metrics.
    - **Presentation Goal:** Explain the Bollinger Band indicator and mean reversion concept. Present backtest results (equity curve, Sharpe, drawdown, win rate). Analyze performance and discuss potential improvements or risks (e.g., trend risk).
3. **GARCH Model for Volatility Forecasting & Visualization:**
    - **Objective:** Apply a GARCH(1,1) model to forecast the daily volatility of a market index (e.g., SPY) and visualize the forecasts against actual realized volatility.
    - **Tasks:** Get historical daily price data for SPY. Calculate daily returns. Fit a GARCH(1,1) model to the returns (using libraries like `arch`). Generate 1-day ahead volatility forecasts. Calculate realized volatility (e.g., standard deviation of returns over a short trailing window like 5 days). Plot the GARCH forecasts alongside the realized volatility.
    - **Presentation Goal:** Explain the basics of GARCH models for volatility clustering. Show the plot comparing forecasted vs. realized volatility. Discuss the model's fit and predictive quality based on the visualization and potentially basic error metrics.Ma
4. **Comparing RSI vs. Stochastic Oscillator Strategies:**
    - **Objective:** Implement and compare the backtested performance of two simple oscillator-based strategies (one using RSI, one using Stochastic Oscillator) on the same currency pair (e.g., EUR/USD) or commodity (e.g., Crude Oil futures).
    - **Tasks:** Get historical price data. Define clear buy/sell rules for an RSI strategy (e.g., buy < 30, sell > 70). Define clear buy/sell rules for a Stochastic Oscillator strategy (e.g., based on %K/%D crossovers or overbought/oversold levels). Implement backtests for both strategies separately. Calculate and compare key performance metrics (Sharpe, Drawdown, Profit Factor).
    - **Presentation Goal:** Explain both indicators briefly. Present a comparative table of backtest results. Discuss which strategy performed better on the chosen asset/period and potential reasons or caveats. Analyze consistency and robustness.
5. **Simple ML Model (Random Forest) for Market Regime Detection:**
    - **Objective:** Build a simple classification model (e.g., Random Forest) to classify market regimes (e.g., High Volatility vs. Low Volatility) based on technical indicators derived from a market index (SPY).
    - **Tasks:** Get historical price data for SPY. Calculate features like rolling volatility (e.g., 20-day), Average True Range (ATR), and maybe return skewness/kurtosis. Define the target variable: classify each day as 'High Vol' or 'Low Vol' based on whether rolling volatility is above/below a threshold (e.g., its historical median or a specific percentile). Train a Random Forest classifier. Evaluate its accuracy using appropriate methods (e.g., cross-validation, confusion matrix).
    - **Presentation Goal:** Explain the features used and the regime definition. Present model performance metrics (accuracy, precision, recall). Discuss feature importance from the Random Forest model. Analyze the model's effectiveness and limitations.
6. **Options Strategy Payoff Visualization Tool:**
    - **Objective:** Develop a Python tool (using functions or a simple class) that takes options parameters (strike prices, premiums, long/short positions) for common strategies (e.g., Covered Call, Straddle, Strangle, Vertical Spread) and generates a payoff diagram at expiration.
    - **Tasks:** Define functions for calculating the payoff of individual long/short calls and puts at expiration based on underlying price. Combine these to create functions for specific strategies (e.g., Straddle = long call + long put at same strike). Use Matplotlib to plot the strategy's payoff against a range of possible underlying prices at expiration.
    - **Presentation Goal:** Demonstrate the tool with examples for 3-4 common strategies. Show the generated payoff diagrams and explain how they illustrate the risk/reward profile of each strategy. Discuss the tool's structure and potential extensions (e.g., adding break-even points). (Note: This is less about market analysis and more about building a useful quant finance tool).

---

## Project Timeline & Deliverables

**Week 1 (Apr 9th - April 13th): Kick-off & Planning**

- Select project & define specific goals/hypotheses
- Gather, clean, and preprocess necessary data
- Perform initial exploratory data analysis (Layer 1) or set up backtesting environment (Layer 2)
- *Mentor Action:* Verify data, assist with cleaning/preprocessing, review initial setup

**Week 2 (Apr 14 - Apr 18): Implementation & Core Testing**

- Develop the core model/analysis (Layer 1) or code the trading strategy logic (Layer 2)
- *Mentor Action:* Review code/model logic, provide support, discuss initial results/challenges

**Week 3 (Apr 21 - Apr 25): Evaluation & Refinement**

- Run full analysis/backtests and calculate performance metrics
- Interpret results, note limitations, and make necessary refinements
- *Mentor Action:* Discuss results/metrics, guide interpretation and refinement, discuss challenges/limitations

**Week 5 (Apr 28 - April 30th): Finalize, Submit, Present**

- Complete code documentation and final presentation/paper
- Rehearse presentation.
- April 30th: Final Presentation to other groups.

---

### Presentation & Deliverables

- **Structure:** Organize your final presentation logically.
    - A typical structure includes: Introduction/Motivation, Data Description, Methodology, Results, Analysis/Critique, Conclusion, and Future Work.
- **Clarity:** Explain technical concepts clearly.
    - Use effective visualizations to support your findings. Be prepared to answer questions about your approach and results.
- **Deliverables:**
    - A clean, runnable code repository (e.g., GitHub link).
        - Use this [Template](https://www.notion.so/Digital-Assets-11c8dd6559868035a94de83f7cd94b40?pvs=21) for your presentation
    - A final presentation (.pdf, ~10-15 slides).
    - One Pager

**Submit Deliverables by End of Week.**

- *Mentor Action:*
    - Review final deliverables, provide feedback, conduct mock presentation if needed

**General Mentor Guidance (Based on):**

- Conduct weekly check-ins.
- Assist with problem-solving (technical and conceptual).
- Review work at each milestone and provide feedback.
- Encourage self-reflection on progress.

---

### Tools, Libraries & Data Sources

- **Core Stack:** Projects should primarily use Python. Essential libraries include
    - **Pandas** (data manipulation),
    - **NumPy** (numerical operations),
    - **Matplotlib/Seaborn** (visualization),
    - **Statsmodels** (statistical modeling), and
    - **Scikit-learn** (machine learning).
- **Backtesting (Layer 2):** For strategy projects, consider libraries like `vectorbt` or `backtrader`. Tradingview also works for backtesting.
- **Data:** Start with accessible sources like Yahoo Finance (via `yfinance`) or FRED economic data (via `pandas-datareader`). Document your data sources clearly. Be aware of the limitations and potential quality issues of free data. If using APIs, handle keys responsibly.
- **IDE:** Use an environment you're comfortable with (VS Code, PyCharm, Jupyter Notebooks/Lab).
- Do research before you start! Make sure you understand the resources.

### PowerPoint Template:

[2025 TradersAtSMU Template.potx](2025%20Projects%20Traders@SMU%201c88dd6559868067b01bd6a154e6d01e/2025_TradersAtSMU_Template.potx)

---

### Coding Standards, Collaboration & Version Control

- **Readability:** Write clear, well-commented code.
- **Collaboration:** Discuss within your group how to divide tasks effectively. Regular communication is key.
- **Version Control:** **Using Git and GitHub is strongly recommended.** Maintain a clean repository for your project code. This is crucial for collaboration and tracking changes.

---